package com.course.kafka.producer;

import org.springframework.stereotype.Service;
import com.course.kafka.entity.Commodity;
import com.course.kafka.entity.Employee;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class CommodityProducer extends AbstractKafkaProducer{

    private ObjectMapper objectMapper;

    public CommodityProducer(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public void sendMessage(Commodity commodity) throws JsonProcessingException {
        var json = objectMapper.writeValueAsString(commodity);
        this.kafkaTemplate.send("t-commodity", commodity.getName() , json);
    }
}
