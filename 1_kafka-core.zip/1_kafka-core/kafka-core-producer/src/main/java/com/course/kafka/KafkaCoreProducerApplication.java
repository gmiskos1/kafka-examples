package com.course.kafka;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.WebProperties;
import org.springframework.scheduling.annotation.EnableScheduling;
import com.course.kafka.entity.Employee;
import com.course.kafka.producer.EmployeeJsonProducer;
import com.course.kafka.producer.FixedRateProducer;
import com.course.kafka.producer.HelloKafkaProducer;
import com.course.kafka.producer.KafkaKeyProducer;

@SpringBootApplication
@EnableScheduling
public class KafkaCoreProducerApplication implements CommandLineRunner {

	//private HelloKafkaProducer kafkaProducer;
	//private FixedRateProducer kafkaProducer;
	//private KafkaKeyProducer kafkaProducer;
	//private EmployeeJsonProducer kafkaProducer;


//	public KafkaCoreProducerApplication(EmployeeJsonProducer kafkaProducer) {
//		this.kafkaProducer = kafkaProducer;
//	}

	public static void main(String[] args) {
		SpringApplication.run(KafkaCoreProducerApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		//kafkaProducer.send("George"); // this is for hello kafka producer
		//kafkaProducer.sendMessage(); // this is for fixed rate producer

//		for(int i=0; i<10_000 ; i++){ // this is for kafka key producer
//			var key = "key-"+(i%4);
//			var value = "value " + i + " with key " +key;
//			kafkaProducer.send(key, value);
//			TimeUnit.SECONDS.sleep(1);
//		}
//		for(int i = 0; i < 5 ; i++){ // this is for employee producer
//			kafkaProducer.sendMessage(new Employee("empl-"+i, "Employee "+i, LocalDate.now()));
//		}
			}
}
