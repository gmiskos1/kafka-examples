package com.course.kafka.producer;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class HelloKafkaProducer extends AbstractKafkaProducer{

    public HelloKafkaProducer() {
        super();
    }

    public void send(String name){
        this.kafkaTemplate.send("t-hello", "Hello "+name);
    }
}
