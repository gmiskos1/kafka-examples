package com.course.kafka.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.course.kafka.entity.Employee;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class EmployeeJsonProducer extends AbstractKafkaProducer{

    private ObjectMapper objectMapper;

    public EmployeeJsonProducer(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public void sendMessage(Employee employee) throws JsonProcessingException {
        var json = objectMapper.writeValueAsString(employee);
        this.kafkaTemplate.send("t-employee", json);
    }
}
